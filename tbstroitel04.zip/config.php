<?php
session_start();

// Настройки бота Telegram
define('BOT_TOKEN', '8441566431:AAH46CQN7J-V3Dn9b7L67GuZIx_FhbunDWw'); // Замените на реальный токен
define('CHAT_ID', '5130071892');      // Замените на ваш chat_id

// Защита от CSRF
if (empty($_SESSION['csrf_token'])) {
    $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
}

// Базовые настройки
header('X-Frame-Options: DENY');
?>