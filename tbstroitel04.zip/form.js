document.getElementById('telegramForm').addEventListener('submit', function(e) {
  e.preventDefault();
  
  const formData = new FormData(this);
  const message = `Новая заявка!\nИмя: ${formData.get('name')}\nТелефон: ${formData.get('phone')}\nУслуга: ${formData.get('service')}`;
  
  const botToken = '8441566431:AAH46CQN7J-V3Dn9b7L67GuZIx_FhbunDWw';
  const chatId = '5130071892';
  
  fetch(`https://api.telegram.org/bot${botToken}/sendMessage`, {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
    },
    body: JSON.stringify({
      chat_id: chatId,
      text: message
    })
  })
  .then(response => {
    if (response.ok) {
      alert('Заявка отправлена! Мы скоро свяжемся с вами.');
      this.reset();
    } else {
      throw new Error('Ошибка отправки');
    }
  })
  .catch(error => {
    console.error('Error:', error);
    alert('Произошла ошибка. Пожалуйста, позвоните нам напрямую.');
  });
});