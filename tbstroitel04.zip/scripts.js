// Portfolio Filter
document.querySelectorAll('.filter-btn').forEach(btn => {
  btn.addEventListener('click', () => {
    const filter = btn.dataset.filter;
    
    // Update active button
    document.querySelectorAll('.filter-btn').forEach(b => b.classList.remove('active'));
    btn.classList.add('active');
    
    // Filter projects
    document.querySelectorAll('.project').forEach(project => {
      if (filter === 'all' || project.dataset.category === filter) {
        project.style.display = 'block';
      } else {
        project.style.display = 'none';
      }
    });
  });
});

// Testimonial Slider
let currentSlide = 0;
const testimonials = document.querySelectorAll('.testimonial');

function showSlide(index) {
  testimonials.forEach(slide => slide.classList.remove('active'));
  currentSlide = (index + testimonials.length) % testimonials.length;
  testimonials[currentSlide].classList.add('active');
}

document.querySelector('.next').addEventListener('click', () => showSlide(currentSlide + 1));
document.querySelector('.prev').addEventListener('click', () => showSlide(currentSlide - 1));

// Auto-slide every 5 seconds
setInterval(() => showSlide(currentSlide + 1), 5000);

// Form Submission
document.querySelector('#applicationForm').addEventListener('submit', async (e) => {
  e.preventDefault();
  const form = e.target;
  const submitBtn = form.querySelector('button[type="submit"]');
  
  try {
    // Блокируем кнопку при отправке
    submitBtn.disabled = true;
    
    // Валидация (пример для поля телефона)
    const phone = form.querySelector('#phone').value;
    if (!/^\+?[0-9\s\-\(\)]+$/.test(phone)) {
      throw new Error('Введите корректный номер телефона');
    }
    
    // Собираем данные формы
    const formData = new FormData(form);
    
    // Отправка на сервер
    const response = await fetch('send.php', {
      method: 'POST',
      body: formData
    });
    
    if (!response.ok) throw new Error('Ошибка сервера');
    
    const result = await response.json();
    
    if (result.success) {
      alert('Заявка отправлена! Мы свяжемся с вами в ближайшее время.');
      form.reset();
    } else {
      throw new Error(result.message || 'Ошибка при отправке');
    }
    
  } catch (error) {
    console.error('Ошибка:', error);
    alert(error.message || 'Произошла ошибка. Пожалуйста, попробуйте позже.');
  } finally {
    submitBtn.disabled = false;
  }
  submitBtn.innerHTML = '<span class="loader">Отправка...</span>';
// После finally:
submitBtn.innerHTML = 'Отправить';
});

    
    // Остальной код валидации оставить без изменений
    // ... (функции validateForm, validateField, showSuccessMessage и др.)
});
    
    // Валидация в реальном времени
    form.querySelectorAll('input, select').forEach(input => {
        input.addEventListener('input', function() {
            validateField(this);
        });
    });
});

function validateForm() {
    let isValid = true;
    const form = document.getElementById('applicationForm');
    
    // Проверка reCAPTCHA
    if (grecaptcha.getResponse() === '') {
        showErrorMessage('Пожалуйста, подтвердите, что вы не робот');
        isValid = false;
    }
    
    // Проверка полей
    form.querySelectorAll('input[required], select[required]').forEach(field => {
        if (!validateField(field)) {
            isValid = false;
        }
    });
    
    return isValid;
}

function validateField(field) {
    const errorElement = field.nextElementSibling;
    
    if (!field.checkValidity()) {
        errorElement.style.display = 'block';
        errorElement.textContent = getErrorMessage(field);
        return false;
    } else {
        errorElement.style.display = 'none';
        return true;
    }
}

function getErrorMessage(field) {
    if (field.validity.valueMissing) {
        return 'Это поле обязательно для заполнения';
    }
    if (field.validity.patternMismatch && field.id === 'phone') {
        return 'Введите корректный номер телефона';
    }
    if (field.validity.tooShort) {
        return `Минимальная длина: ${field.minLength} символов`;
    }
    return 'Неверное значение';
}

function showSuccessMessage(message) {
    const element = document.getElementById('successMessage');
    element.style.display = 'block';
    element.textContent = message;
    element.style.backgroundColor = '#d4edda';
    element.style.color = '#155724';
}

function showErrorMessage(message) {
    const element = document.getElementById('successMessage');
    element.style.display = 'block';
    element.textContent = message;
    element.style.backgroundColor = '#f8d7da';
    element.style.color = '#721c24';
}
.then(data => {
    if (data.success) {
        alert('✅ Заявка успешно отправлена!');
    } else {
        alert('❌ Ошибка: ' + data.message);
    }
})