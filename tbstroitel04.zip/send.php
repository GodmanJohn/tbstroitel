<?php
header('Content-Type: application/json');

// Конфигурация (лучше вынести в отдельный файл)
require_once 'config.php'; // Файл с define('BOT_TOKEN', 'ваш_токен');

// Включение логов
ini_set('display_errors', 0); // На продакшене лучше отключать
error_reporting(E_ALL);
define('LOG_FILE', __DIR__.'/debug.log');

// Функция для логирования
function log_message($message) {
    file_put_contents(LOG_FILE, date('[Y-m-d H:i:s] ').$message.PHP_EOL, FILE_APPEND);
}

// Проверка CSRF-токена
if (empty($_POST['csrf_token']) || $_POST['csrf_token'] !== $_SESSION['csrf_token']) {
    http_response_code(403);
    die(json_encode(['ok' => false, 'error' => 'Invalid CSRF token']));
}

// Получение и валидация данных
$data = json_decode(file_get_contents('php://input'), true) ?: $_POST;
$name = trim($data['name'] ?? '');
$phone = trim($data['phone'] ?? '');
$service = trim($data['service'] ?? 'Не указана');

// Проверка обязательных полей
if (empty($name) || empty($phone)) {
    http_response_code(400);
    die(json_encode(['ok' => false, 'error' => 'Заполните все обязательные поля']));
}

// Очистка данных
$name = htmlspecialchars($name, ENT_QUOTES, 'UTF-8');
$phone = htmlspecialchars($phone, ENT_QUOTES, 'UTF-8');
$service = htmlspecialchars($service, ENT_QUOTES, 'UTF-8');

// Формирование сообщения
$text = "📌 *Новая заявка с сайта*\n";
$text .= "👤 Имя: *$name*\n";
$text .= "📱 Телефон: `$phone`\n";
$text .= "🛠 Услуга: $service\n";
$text .= "⏱ Время: ".date('d.m.Y H:i');

// Отправка в Telegram
$url = "https://api.telegram.org/bot".BOT_TOKEN."/sendMessage";
$params = [
    'chat_id' => CHAT_ID,
    'text' => $text,
    'parse_mode' => 'Markdown'
];

$ch = curl_init();
curl_setopt_array($ch, [
    CURLOPT_URL => $url,
    CURLOPT_POST => true,
    CURLOPT_POSTFIELDS => $params,
    CURLOPT_RETURNTRANSFER => true,
    CURLOPT_TIMEOUT => 15,
    CURLOPT_HTTPHEADER => ['Content-Type: multipart/form-data']
]);

$response = curl_exec($ch);
$http_code = curl_getinfo($ch, CURLINFO_HTTP_CODE);
$error = curl_error($ch);
curl_close($ch);

// Обработка ответа
if ($response === false) {
    log_message("cURL Error: $error");
    http_response_code(500);
    die(json_encode(['ok' => false, 'error' => 'Ошибка соединения с Telegram']));
}

$response_data = json_decode($response, true);
if (!$response_data || !$response_data['ok']) {
    $error_msg = $response_data['description'] ?? 'Unknown error';
    log_message("Telegram API Error: $error_msg");
    http_response_code(500);
    die(json_encode(['ok' => false, 'error' => $error_msg]));
}

// Успешный ответ
log_message("Successfully sent to Telegram: $name, $phone");
echo json_encode([
    'ok' => true,
    'message' => 'Заявка отправлена!',
    'message_id' => $response_data['result']['message_id']
]);
?>

